"""

Kook Tae Kim, and Dong Ryeol Lee, Probabilistic Parameter Estimation Using a Gaussian Mixture Density Network: Application to X-ray Reflectivity Data Curve Fitting, J. Appl. Cryst. ( ). vol, page

Dept of physics, Soongsil University, Seoul, Rep of Korea
Non-commercial use only

2021-08-30

"""


import numpy as np
from math import erf, sqrt
from numba import njit, prange
import random as rd
import pandas as pd
import lmfit as lmf
import matplotlib.pyplot as plt
import plotly.express as px
from sklearn.cluster import KMeans
import tensorflow as tf
import tensorflow_probability as tfp
from tensorflow import keras
from keras import optimizers
from keras.models import Sequential, Model
from keras.layers import Dense, Layer, Input
from tensorflow.keras import initializers
from tqdm import tqdm

tfpl = tfp.layers
tfd = tfp.distributions
tfk = tf.keras
tfkl = tf.keras.layers


# Beam line settings.
class Experiment:
    
    def __init__(self, Specimen):
        
        self.specimen = Specimen
        
    
    def Initialize(self):
   
            
        self.lamb = 12.3984 / self.Energy
        self.k0 = 2 * np.pi / self.lamb
        self.qz = 4 * np.pi / self.lamb * np.sin( self.ScanRange_deg * np.pi / 180 )
        self.rad = self.ScanRange_deg * np.pi / 180

            
    def a2Scan(self):
        
        delta_prof, beta_prof, z = self.specimen.DrawProfile()
        XRR = CalcXRR( self.rad, delta_prof, beta_prof, \
                       self.specimen.N_prof, self.specimen.d_slab\
                       , self.k0, self.block_angle , self.detector_resol)
        return XRR


#Sample
class Specimen:
    
    def __init__(self, N_layer, d_slab, total_thickenss):
        
        self.N_layer = N_layer
        self.d_slab = d_slab
        self.N_prof = int(total_thickenss / d_slab)
        
        self.delta = np.zeros(    self.N_layer + 2   ,dtype = np.float64 )
        self.beta = np.zeros(    self.N_layer + 2   ,dtype = np.float64 )
        self.d_table = np.zeros(  self.N_layer + 2  ,dtype = np.float64)
        self.rms = np.zeros(  self.N_layer + 2 ,dtype = np.float64 )
        self.prof_delta = np.zeros(   self.N_prof   ,dtype = np.float64 )
        self.prof_beta = np.zeros(    self.N_prof   ,dtype = np.float64 )
        self.z = np.zeros(  self.N_layer + 2 ,dtype = np.float64 )

        self.n_layer = 0
        self.name_dict = dict()
        self.delta_dict = dict()
        self.beta_dict = dict()
        
    def Sub(self, name, delta, beta, sig ):
        
        self.sub_name = name
        self.z[ 0 ] = 0 
        self.delta[ 0 ] = delta
        self.beta[ 0 ] = beta
        self.rms[ 0 ] = sig
        
    def AddLayer(self, name, delta, beta, r, t, sig ):
        
        self.n_layer += 1
        self.name_dict[name] = self.n_layer
        
        self.delta_dict[name] = delta
        self.beta_dict[name] = beta
        
        self.delta[ self.name_dict[ name ] ] = delta * r
        self.beta[ self.name_dict[ name ] ] = beta * r
        self.d_table[ self.name_dict[ name ] ] = t
        self.rms[ self.name_dict[ name ] ] = sig
    
    
    def UpdateSub(self, name, sig):
        self.rms[ 0 ] = sig
        
    def UpdateLayer(self, name, r, t, sig ):
        
        self.delta[ self.name_dict[ name ] ] = self.delta_dict[name] * r
        self.beta[ self.name_dict[ name ] ] = self.beta_dict[name] * r
        self.d_table[ self.name_dict[ name ] ] = t
        self.rms[ self.name_dict[ name ] ] = sig
        
    def DrawProfile(self):
        
        self.prof_delta = np.zeros(   self.N_prof   ,dtype = np.float64 )
        self.prof_beta = np.zeros(    self.N_prof   ,dtype = np.float64 )
        
        z = np.linspace(0, self.d_slab * self.N_prof, self.N_prof)
        
        d,b = DrawProfile_fast(self.prof_delta, self.prof_beta, self.delta, self.beta \
                        , self.rms, self.d_table, self.z, self.N_prof ,self.d_slab, self.N_layer)
        
        
        return d,b,z

# MDN model
class XMachine:
    
    def __init__(self, parameter, Exp_obj, th, exp_data ) :
        
        self.p = parameter
        self.Exp_obj = Exp_obj
        self.th = th
        self.exp_data = exp_data
        
        self.par_temp = lmf.Parameters()
        
        for i in list(self.p.keys()):

            if self.p[i].vary ==1:
                self.par_temp.add(self.p[i])
        
    def ProduceData(self, N_data, path_xrr, path_par):
        
        produceData(self.p, self.Exp_obj, self.th, N_data, path_xrr, path_par)
        
    def ReadData(self, path_xrr, path_par, chunksize ):
        
        self.X = readTrainData( path_xrr, chunksize = chunksize )
        self.Y = readTrainData( path_par, chunksize = chunksize )
        
    def PreProcessing(self):
        self.meanX = self.X.mean(axis = 0)
        self.stdX = self.X.std(axis=0)
        self.X_in = (self.X - self.meanX )/self.stdX
        self.I_11keV_norm = (self.exp_data - self.meanX )/self.stdX
        self.N_data = len(self.I_11keV_norm)
        
    def TrainTestSplit(self, train_size, test_rate):
        # split test and train data
        self.train_size = train_size
        self.test_rate = test_rate
        self.X_train, self.Y_train, self.X_test, self.Y_test = train_test_split( self.X_in[:self.train_size], \
                                                                                self.Y[:self.train_size],\
                                                                                self.test_rate )
        
    def MakeModel_MDN(self, layer_architecture, n_mixture):
        # regression model.
        event_shape = [self.Y_train.shape[1]]
        num_components = n_mixture # mixture number
        params_size = tfpl.MixtureNormal.params_size(num_components, event_shape)

        inputs = tfkl.Input(shape=(self.X_train.shape[1]))
        layer= tfkl.Dense(layer_architecture[0], activation='relu'\
                    ,kernel_initializer=initializers.RandomNormal(stddev=0.01))(inputs)
        
        for i in range( 1, len( layer_architecture ) ):
            layer= tfkl.Dense(layer_architecture[i], activation='relu'\
                        ,kernel_initializer=initializers.RandomNormal(stddev=0.01))(layer)

        layer = tfkl.Dense(params_size, activation=None)(layer)
        outputs = tfpl.MixtureNormal(num_components=num_components, event_shape=event_shape)(layer)

        self.model = keras.Model(inputs=inputs, outputs=outputs)

        self.model.compile(optimizer=tf.optimizers.Adam(), 
            loss=lambda y, model: tf.reduce_mean( tf.negative( model.log_prob( y ) ) ) )
        
    def TrainModel(self, batch_size, epoch, validation_rate):
        # Train.
        callback = tf.keras.callbacks.EarlyStopping(monitor='loss', patience=5)
        self.model.summary()
        self.history = self.model.fit(self.X_train, self.Y_train,batch_size=batch_size,epochs=epoch, \
                            validation_split = validation_rate,)
    def ShowLoss(self):
        # Check loss function.
        plt.figure(figsize = (8,5))
        plt.plot(self.history.history['loss'] ,'.-k',label='train data' )
        plt.plot(self.history.history['val_loss'],'.-r', label = 'validation data')
        plt.legend(prop ={'size': 20}, frameon = 0)
        plt.xlabel('Epoches', size = 35)
        plt.ylabel('MSE Loss', size = 35)
        plt.tick_params(labelsize = (25))
        plt.tight_layout()

    def ShowR2(self):
        # Check R2
        value = self.model(self.X_test)
        mean = np.array(value.mean())
        sig = np.array(value.stddev())
        print('R2 score = ',R2(self.Y_test,mean ))
        
    def SamplingPDF(self, N_sample ):
        
        self.y_sample = []
        value = self.model(self.I_11keV_norm.reshape( 1, self.N_data ) )
        
        for i in range( 0, N_sample ):

            self.y_sample.append(value.sample().numpy()[0])

        self.y_sample = np.array(self.y_sample)
    
    def Show1DPDF( self, par_name  ):
        
        
        n_par = list( self.par_temp  ).index(par_name)
        
        dp = self.par_temp[par_name].max - self.par_temp[par_name].min 

        y_trans = self.y_sample[:, n_par ] * dp + self.par_temp[par_name].min 
        
        plt.figure(figsize = ( 8,5))
        n, b, patches = plt.hist( y_trans, 100, label = 'Model Distribution')
        bin_max = np.where(n == n.max())
        print('maxbin=', b[bin_max][0])
        plt.legend(prop ={'size': 15}, frameon = 0)
        plt.tick_params(labelsize = 30)
        plt.tight_layout()
    
    def Show2DPDF( self, x_name, y_name, centroid =False ) :
    

        n_par_x = list( self.par_temp  ).index( x_name )
        n_par_y = list( self.par_temp  ).index( y_name )

        dp_x = self.par_temp[x_name].max - self.par_temp[x_name].min 
        dp_y = self.par_temp[y_name].max - self.par_temp[y_name].min 

        x_trans = self.y_sample[:, n_par_x ] * dp_x + self.par_temp[x_name].min 
        y_trans = self.y_sample[:, n_par_y ] * dp_y + self.par_temp[y_name].min 

        df = pd.DataFrame({ x_name: x_trans, y_name : y_trans } )

        fig = px.density_heatmap(df, x=x_name, y=y_name, marginal_x="histogram", marginal_y="histogram",
                                  nbinsx = 100, nbinsy = 100, width = 600, height = 500, range_color=[0,10])

        fig.update_layout(
        font=dict(size=20,)
        )

        fig.show()
        #fig.write_image('plotlytest_3.pdf')
        
        
    def FindCentroid(self, n_means, n_max ):
        
        self.n_means = n_means
        
        kmeans = KMeans(n_clusters=n_means)
        
        df = pd.DataFrame(self.y_sample, columns = list( self.par_temp.keys() ) )

        self.index = kmeans.fit_predict(df)
        
        self.centroid = kmeans.cluster_centers_
        
        self.centroid_trans = []
        
        k = 0
        for i in list( self.par_temp.keys( ) ):
            
            dp = self.par_temp[i].max - self.par_temp[i].min 
            self.centroid_trans.append(  self.par_temp[i].min + dp * self.centroid[:,k]  )
            print( i, "'s centroid =", np.round(self.centroid_trans[ k ],3) )
            k+=1
        
        self.centroid_trans = np.array( self.centroid_trans )
        
        distortions = []
        
        for i in range(1, n_max):
            km = KMeans(n_clusters=i)
            km.fit(df)
            distortions.append(km.inertia_)

        plt.figure(figsize = ( 8,5 ) )
        plt.plot( range( 1,  n_max ), distortions, 'ko-')
        plt.xlabel( 'Number of clusters', size = 20)
        plt.ylabel( 'Inertia', size = 20)
        plt.tick_params(labelsize = 20)
        plt.tight_layout()
    
        
    def CheckXRR( self ):
    
        plt.figure(figsize = (8,5))
        plt.plot(self.th, self.exp_data,'ko',markerfacecolor = 'none' )

        for n in range(0, self.n_means ):
            k = 0
            for i in list(self.par_temp.keys()):
                self.par_temp[i].value = self.centroid_trans[:,n][k]
                k+=1
                
            par_tempp = dict(self.par_temp.valuesdict())
            self.Exp_obj.specimen.UpdateLayer(name = 'PtTop', r = par_tempp['r_PtTop'], t = par_tempp['t_PtTop'], sig = par_tempp['rms_air_PtTop'])
            self.Exp_obj.specimen.UpdateLayer(name = 'Co', r = par_tempp['r_Co'], t = par_tempp['t_Co'], sig =par_tempp['rms_PtTop_Co'])
            self.Exp_obj.specimen.UpdateLayer(name = 'PtBot', r = par_tempp['r_PtBot'], t = par_tempp['t_PtBot'], sig = par_tempp['rms_Co_PtBot'])
            self.Exp_obj.specimen.UpdateSub(name = 'AlO3', sig =par_tempp['rms_PtBot_sub'])
            self.Exp_obj.block_angle = par_tempp['thb']
            
            R = self.Exp_obj.a2Scan()
            R = np.log10(R * self.Exp_obj.qz ** 4)
            plt.plot(self.Exp_obj.ScanRange_deg, R, label = 'cluster_'+ str(n))
        
        plt.xlabel('Incident Angle', size = 20)
        plt.legend(prop = {'size':15}, frameon = 0)
        plt.tick_params(labelsize = 20) 
    
   
    
"""
XRR calculation functions.
"""

@njit
def DrawProfile_fast(prof_delta, prof_beta, delta, beta, rms, d_table, z, N_prof , d_slab, N_layer ):
    
    
    # air
    delta[ N_layer + 1 ] = 0.
    
    beta[ N_layer + 1 ] = 0.
    
    for i in range( 1, N_layer + 1 ) :
        
        z[ i ] = ( z[ i-1 ] + d_table[ i ] ) 
        
    z_offSet = 50
        
    for n in range( 0, N_prof ) :
        X_p = n * d_slab - z_offSet

        for i in range( 0, N_layer + 1 ) :
            prof_delta[ n ] += ( delta[ N_layer - i ] - delta[ N_layer - i + 1 ] ) / 2.* ( 1.+ erf( ( z[ N_layer-i ] - X_p ) / ( sqrt( 2. ) * rms[ N_layer - i ] ) ) )
            prof_beta[ n ] += ( beta[ N_layer - i ] - beta[ N_layer - i + 1 ]) / 2.* ( 1. + erf( ( z[ N_layer - i ] - X_p ) / ( sqrt( 2. ) * rms[ N_layer - i ] ) ) )
    
    
    return  prof_delta,  prof_beta 

@njit
def CalcXRR(rad, delta_prof, beta_prof, N_prof, d_slab, k0, block_angle, detector_resol):
    
    XRR = np.zeros( len( rad ) ,dtype = np.float64)
    
    for i in range( 0, len(rad) ):
        
        XRR [i] = refl_calc( rad[i], k0, delta_prof, beta_prof,N_prof, d_slab,  's')
    
    XRR = beamsizeEff( XRR, rad, block_angle )
    XRR = resolutionEff( rad, detector_resol , XRR )
    
    return XRR
    
@njit
def wavenum_z(rad,delta,beta,k0):
    
    u = np.sin(rad)**2 - 2 * delta + 1j * 2. * beta
    v = np.sqrt(u)
    v = v.real + 1j * np.abs(v.imag)
    z=v*k0
    
    return z


@njit
def Fresnel_r( a, b ):
    
    c = a + b
    
    d = a - b
    
    z = d / c
    
    return z


@njit
def Reflect( a, b, c, d ) :
    
    u1 = -2 * d * c.imag + 1j * 2 * d * c.real
    
    u2 = np.exp( u1 )
    u3 = b * u2
    u4 = a + u3
    u5 = a * u3
    u6 = ( u5.real + 1 ) + 1j * u5.imag
    
    z = u4 / u6
    return z

@njit
def refl_calc(rad, k0, profdelta, profbeta,N_prof,d_slab, pol):
    
    kzz = np.empty(  N_prof ,dtype=np.complex64)
    
    r = np.empty(  N_prof-1 ,dtype=np.complex64)
    
    R = np.empty(  N_prof-1,dtype=np.complex64) 
    
    n = np.empty(  N_prof, dtype=np.complex64) 
            
    for i in range(  0, N_prof  ) :

        kzz[N_prof-1-i]=wavenum_z(rad,profdelta[i],profbeta[i],k0)

    for i in range(0,N_prof-1) :

        r[i]=Fresnel_r(kzz[i],kzz[i+1])
    
    
    R[N_prof-2] = r[N_prof-2]
    
    for i in range(1,N_prof-1) :
        
        j=N_prof-2-(i)
        
        R[j] = Reflect(r[j],R[j+1],kzz[j+1],d_slab)
    
        
    
    return R[0].real**2 + R[0].imag**2

@njit
def filterr(  x, mean, sig  ) :
    
    fi = np.exp(  -(  x - mean  )**2 / (  2 * sig**2  )  ) / (  np.sqrt(  2 * np.pi  ) * sig  )
    
    return fi

@njit
def resolutionEff(x, p, y_fit):
    
    sig_conv = p * np.pi / 180
    
    dx = x[1] - x[0]
    
    N_pad = int( 11 * sig_conv / dx )

    N_1 = int(N_pad/2)
    N_2 = N_1
    
    x_conv = np.linspace(0 - N_1 * dx ,0 + N_2 * dx, N_pad )
    
    y_filter = filterr(  x_conv, 0, sig_conv  )

    y_fit = np.convolve(  y_filter, y_fit  ) / y_filter.sum()
   
    return y_fit[N_1: N_1 + len(x) ]

@njit
def beamsizeEff(y_fit, rad, th_b) :
    
    for i in range(0,len(rad)) :
        
        if( rad[i] <= th_b * np.pi / 180 ) :
            
            y_fit[i] = y_fit[i] * np.sin(rad[i]) / (np.sin(th_b * np.pi / 180))
            
    return y_fit


def readTrainData(path, chunksize):
    """
    This function reads the training and test data set using pandas data frame.
    path : Path for the training data.
    return : Training data.
    """
    
    X_data = pd.read_csv(path, chunksize =chunksize ,delimiter= ' ')

    j = 0
    
    X =[]
    
    for i in X_data:

        X.append(i.values)

        j+=1

        if j == 1:

            break
            
    X2 = []
    
    for i in range(0, len(X[0])):
        
        X2.append(X[0][i][:-1])
    
    X2 = np.array(X2)
    
    return X2

def train_test_split(  X, Y, rate ):
    
    N_train = len(X)
    
    N_test = int( N_train * rate )

    X_train = X[ : N_train - N_test ].copy()
    Y_train = Y[ : N_train - N_test ].copy()

    X_test = X_train[ : N_test ].copy()
    Y_test = Y_train[ : N_test ].copy()
    
    return X_train, Y_train, X_test, Y_test


def R2(y_true, y_pred):
    
    SS_res =  ( ( y_true-y_pred ) ** 2 ).sum()
    
    SS_tot = ( ( y_true -y_true.mean() )** 2 ).sum()
    
    return ( 1 - SS_res/SS_tot  )

def produceData(p, Exp_obj, th, N_data, path_XRR, path_par):
    
    
    xrr_f = open(path_XRR,'w')
    par_f = open(path_par,'w')
    
    for n in tqdm(range(0, N_data)):
        
        r_list = []

        
        for i in p.keys():

            if p[i].vary == 1:
                dp = p[i].max - p[i].min
                r = rd.random()
                p[i].value = p[i].min + dp * r
                r_list.append(r)

            else:
                pass
                
        par = dict( p.valuesdict() )
        Exp_obj.specimen.UpdateLayer(name = 'PtTop', r = par['r_PtTop'], t = par['t_PtTop'], sig = par['rms_air_PtTop'])
        Exp_obj.specimen.UpdateLayer(name = 'Co', r = par['r_Co'], t = par['t_Co'], sig = par['rms_PtTop_Co'])
        Exp_obj.specimen.UpdateLayer(name = 'PtBot', r = par['r_PtBot'], t = par['t_PtBot'], sig = par['rms_Co_PtBot'])
        Exp_obj.specimen.UpdateSub(name = 'AlO3', sig = par['rms_PtBot_sub'])

        Exp_obj.detector_resol = par['d_resol']
        Exp_obj.block_angle = par['thb']
        Exp_obj.ScanRange_deg = th
        R = Exp_obj.a2Scan()
        R = np.log10( R * Exp_obj.qz ** 4 * par['const'] )
                
        p_np = (np.array(r_list)).copy()
        
        xrr_f.write('\n')
        
        par_f.write('\n')
        
        for i in range(0, len(R)):
            xrr_f.write( str(R[i]) +' ' )
        
        for i in range(0, len(p_np)):
            par_f.write( str(p_np[i]) +' ' )
            
    xrr_f.close()
    par_f.close()

    
 